import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Heart, MapPin } from 'lucide-react';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-champagne/8 grain-overlay" style={{ background: 'hsl(350, 50%, 5%)' }}>
      <div className="max-w-7xl mx-auto px-5 md:px-12">
        {/* Main Footer */}
        <div className="py-12 md:py-16 grid grid-cols-2 md:grid-cols-[2fr_1fr_1fr_1fr] gap-8 md:gap-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="mb-5">
              <h3 className="font-serif text-3xl md:text-4xl text-ivory italic mb-1">Shikan</h3>
              <p className="text-[8px] tracking-[0.5em] text-champagne uppercase font-sans">Pastries</p>
            </div>
            <div className="flex items-center gap-1.5 mb-3">
              <MapPin size={10} className="text-champagne/50" />
              <p className="text-[11px] text-ivory/30 font-sans">Maai Mahiu, Nakuru, Kenya</p>
            </div>
            <p className="text-xs text-ivory/25 font-sans font-light leading-relaxed max-w-xs mb-6">
              Artisan pastries handcrafted with love — custom cakes for every occasion.
            </p>
            <div className="flex items-center gap-3">
              {[
                { href: 'https://instagram.com', icon: <Instagram size={12} /> },
                { href: 'https://wa.me/254700000000', icon: (
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                )},
              ].map((s, i) => (
                <a key={i} href={s.href} target="_blank" rel="noopener noreferrer"
                  className="w-8 h-8 border border-champagne/20 flex items-center justify-center text-champagne/40 hover:text-champagne hover:border-champagne/50 transition-all duration-300">
                  {s.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Navigate */}
          <div>
            <p className="text-[8px] tracking-[0.35em] text-champagne/40 uppercase font-sans mb-5">Navigate</p>
            <div className="space-y-3">
              {[
                { label: 'Home', href: '/' },
                { label: 'Collection', href: '/collection' },
                { label: 'Gallery', href: '/gallery' },
                { label: 'Order', href: '/order' },
              ].map(l => (
                <Link key={l.label} to={l.href}
                  className="block text-xs text-ivory/30 font-sans hover:text-champagne transition-colors duration-300">
                  {l.label}
                </Link>
              ))}
            </div>
          </div>

          {/* What We Make */}
          <div>
            <p className="text-[8px] tracking-[0.35em] text-champagne/40 uppercase font-sans mb-5">Specialties</p>
            <div className="space-y-3">
              {['Wedding Cakes', 'Birthday Cakes', 'Kids Cakes', 'Custom Designs', 'Event Spreads'].map(s => (
                <Link key={s} to="/collection"
                  className="block text-xs text-ivory/30 font-sans hover:text-champagne transition-colors duration-300">
                  {s}
                </Link>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <p className="text-[8px] tracking-[0.35em] text-champagne/40 uppercase font-sans mb-5">Contact</p>
            <div className="space-y-3">
              <p className="text-xs text-ivory/30 font-sans">Maai Mahiu, Nakuru</p>
              <p className="text-xs text-ivory/30 font-sans">+254 700 000 000</p>
              <p className="text-xs text-ivory/30 font-sans">hello@shikanpastries.com</p>
              <Link to="/order" className="mt-3 btn-outline inline-block text-[9px]" style={{ padding: '0.5rem 1.2rem' }}>
                <span>Order Now</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-champagne/8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[10px] text-ivory/15 font-sans">
            © {year} Shikan Pastries. All rights reserved.
          </p>
          <p className="text-[10px] text-ivory/12 font-sans flex items-center gap-1">
            Crafted with <Heart size={8} className="text-champagne/35" /> in Maai Mahiu
          </p>
        </div>
      </div>
    </footer>
  );
}